/**
 * Author                : Wechisley Faria
 * Created               : 28/04/2021 21:43:56
 * Source Server Type    : PostgreSQL
 * Source Server Version : 100016
 * Source Catalog        : db_vr
 * Source Schema         : public
 */

-- ----------------------------
-- Sequence structure for tab_aluno_alu_codigo_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tab_aluno_alu_codigo_seq";
CREATE SEQUENCE "tab_aluno_alu_codigo_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tab_curso_cur_codigo_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tab_curso_cur_codigo_seq";
CREATE SEQUENCE "tab_curso_cur_codigo_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for tab_curso_aluno_cal_codigo_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "tab_curso_aluno_cal_codigo_seq";
CREATE SEQUENCE "tab_curso_aluno_cal_codigo_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Table structure for tab_aluno
-- ----------------------------
DROP TABLE IF EXISTS "tab_aluno";
CREATE TABLE "tab_aluno" (
  "alu_codigo" int4 NOT NULL DEFAULT nextval('tab_aluno_alu_codigo_seq'::regclass),
  "alu_nome" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Table structure for tab_curso
-- ----------------------------
DROP TABLE IF EXISTS "tab_curso";
CREATE TABLE "tab_curso" (
  "cur_codigo" int4 NOT NULL DEFAULT nextval('tab_curso_cur_codigo_seq'::regclass),
  "cur_descricao" varchar(50) COLLATE "pg_catalog"."default",
  "cur_ementa" text COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Table structure for tab_curso_aluno
-- ----------------------------
DROP TABLE IF EXISTS "tab_curso_aluno";
CREATE TABLE "tab_curso_aluno" (
  "cal_codigo" int4 NOT NULL DEFAULT nextval('tab_curso_aluno_cal_codigo_seq'::regclass),
  "cal_codigo_aluno" int4,
  "cal_codigo_curso" int4
)
;

-- ----------------------------
-- View structure for vie_disciplina
-- ----------------------------
DROP VIEW IF EXISTS "vie_disciplina";
CREATE VIEW "vie_disciplina" AS  SELECT ca.cal_codigo,
    ca.cal_codigo_aluno,
    a.alu_nome,
    ca.cal_codigo_curso,
    c.cur_descricao,
    c.cur_ementa
   FROM ((tab_curso_aluno ca
     JOIN tab_aluno a ON ((ca.cal_codigo_aluno = a.alu_codigo)))
     JOIN tab_curso c ON ((ca.cal_codigo_curso = c.cur_codigo)));
COMMENT ON VIEW "vie_disciplina" IS 'View contendo os dados completos da tabela tab_curso_aluno';

-- ----------------------------
-- View structure for vie_disciplina_alunos
-- ----------------------------
DROP VIEW IF EXISTS "vie_disciplina_alunos";
CREATE VIEW "vie_disciplina_alunos" AS  SELECT DISTINCT ON (a.cal_codigo_curso) a.cal_codigo,
    a.cal_codigo_aluno,
    a.alu_nome,
    a.cal_codigo_curso,
    a.cur_descricao,
    a.cur_ementa,
    a.alunos
   FROM ( SELECT a1.cal_codigo,
            a1.cal_codigo_aluno,
            a1.alu_nome,
            a1.cal_codigo_curso,
            a1.cur_descricao,
            a1.cur_ementa,
            ( SELECT count(a2.cal_codigo_aluno) AS alunos
                   FROM vie_disciplina a2
                  WHERE (a2.cal_codigo_curso = a1.cal_codigo_curso)) AS alunos
           FROM vie_disciplina a1
          ORDER BY a1.cur_descricao) a;
COMMENT ON VIEW "vie_disciplina_alunos" IS 'View contendo os dados completos da tabela tab_curso_aluno e o total de alunos de cada curso';

-- ----------------------------
-- Primary Key structure for table tab_aluno
-- ----------------------------
ALTER TABLE "tab_aluno" ADD CONSTRAINT "tab_aluno_pkey" PRIMARY KEY ("alu_codigo");

-- ----------------------------
-- Primary Key structure for table tab_curso
-- ----------------------------
ALTER TABLE "tab_curso" ADD CONSTRAINT "tab_curso_pkey" PRIMARY KEY ("cur_codigo");

-- ----------------------------
-- Uniques structure for table tab_curso_aluno
-- ----------------------------
ALTER TABLE "tab_curso_aluno" ADD CONSTRAINT "unq_aluno_curso" UNIQUE ("cal_codigo_aluno", "cal_codigo_curso");

-- ----------------------------
-- Primary Key structure for table tab_curso_aluno
-- ----------------------------
ALTER TABLE "tab_curso_aluno" ADD CONSTRAINT "tab_curso_aluno_pkey" PRIMARY KEY ("cal_codigo");

-- ----------------------------
-- Foreign Keys structure for table tab_curso_aluno
-- ----------------------------
ALTER TABLE "tab_curso_aluno" ADD CONSTRAINT "fk_cursoaluno_aluno" FOREIGN KEY ("cal_codigo_aluno") REFERENCES "tab_aluno" ("alu_codigo") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "tab_curso_aluno" ADD CONSTRAINT "fk_cursoaluno_curso" FOREIGN KEY ("cal_codigo_curso") REFERENCES "tab_curso" ("cur_codigo") ON DELETE RESTRICT ON UPDATE CASCADE;