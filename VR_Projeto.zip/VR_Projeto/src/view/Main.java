package view;

import controler.Banco;
import javax.swing.JOptionPane;

/**
 *
 * @author Wechiley Faria
 */
public class Main {

    public static void main(String[] args) {
        // Verifica se o banco de dados existe, para criar
        Banco banco = new Banco();
        if (!banco.bancoExiste()) {
            int dialogButton = JOptionPane.YES_NO_OPTION;
            if (JOptionPane.showConfirmDialog(null, "Banco de dados db_vr não existe!\nDeseja criar agora?", "Banco de Dados", dialogButton) == JOptionPane.YES_OPTION) {
                if (!banco.criarBanco()) {
                    return;
                }
            } else {
                JOptionPane.showMessageDialog(null, "Banco de dados db_vr não foi criado!\nO sistema será encerrado.", "Banco de Dados", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
        new PrincipalGUI().setVisible(true);
    }
}
