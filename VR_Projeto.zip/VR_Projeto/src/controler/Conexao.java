package controler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Wechisley Faria
 */
public class Conexao {

    private Connection conexao; // Responsavel por realizar a conexão com o banco de dados
    private ResultSet rs; // Responsavel por armazenar o resultado de um pesquisa passada para o statement
    private Statement stm; // Responsavel por executar comandos SQL
    private boolean status = false; // Informa o status atual da conexão

    private static String driver = "org.postgresql.Driver";
    private static String caminho = "jdbc:postgresql://";
    private static String ip = "";
    private static String porta = "";
    private static String banco = "";
    private static String usuario = "";
    private static String senha = "";

    /**
     * Configura os dados para realizar a conexão com o banco de dados
     *
     * @param pIp IP do servidor
     * @param pPorta Porta do servidor
     * @param pBanco Nome do banco de dados
     * @param pUsuario Usuário do banco de dados
     * @param pSenha Senha do banco de dados
     */
    public void setConnection(String pIp, String pPorta, String pBanco, String pUsuario, String pSenha) {
        ip = pIp;
        porta = pPorta;
        banco = pBanco;
        usuario = pUsuario;
        senha = pSenha;
    }

    /**
     * Efetua a conexão com o banco de dados PostgreSQL
     *
     * @return boolean - Informa se a conexão foi realizada com sucesso (Status:
     * True/False)
     */
    private boolean conectar()
            throws SQLException, Exception {
        String url = caminho + ip + ":" + porta + "/" + banco;
        System.setProperty("jdbc.Drivers", driver); // Seta a propriedade do driver de conexão;
        conexao = DriverManager.getConnection(url, usuario, senha); // Realiza a conexão com o banco;
        return getStatusConexao();
    }

    /**
     * Realiza a conexão com o banco de dados PostgreSQL
     *
     * @return Connection - Conexão com o banco de dados
     */
    public Connection getConexao()
            throws SQLException, Exception {
        if (!getStatusConexao()) {
            if (!conectar()) {
                throw new SQLException();
            }
        }
        return conexao;
    }

    /**
     * Fecha a conexão com o banco de dados PostgreSQL
     */
    private void desconectar()
            throws SQLException, Exception {
        fechar(this.rs);
        fechar(this.stm);
        fechar(this.conexao);
    }

    /**
     * Fecha o objeto passado por parâmetro (Connection, Statement, PreparedStatement)
     * @param closeable Objeto a ser fechado
     * @return
     */
    public Conexao fechar(AutoCloseable closeable)
            throws SQLException, Exception {
        try {
            if (closeable != null) {
                closeable.close();
            }
        } finally {
            getStatusConexao();
        }
        return this;
    }

    /**
     * Executa consultas SQL
     *
     * @param SQL Comando SQL que será executado
     * @return boolean - Retorna se o comando foi executrado com sucesso
     */
    public boolean executar(String SQL)
            throws SQLException, Exception {
        boolean retorno = false;
        try {
            stm = getConexao().createStatement();
            stm.execute(SQL);
            retorno = true;
        } finally {
            desconectar();
        }
        return retorno;
    }

    /**
     * Executa consultas SQL com retorno
     *
     * @param SQL Comando SQL que será executado
     * @return Object - Retorno do registro consultado
     */
    public Object executarSQL(String SQL)
            throws SQLException, Exception {
        Object retorno = null;
        try {
            stm = getConexao().createStatement();
            rs = stm.executeQuery(SQL);
            // Captura o retorno do registro
            if (rs != null) {
                while (rs.next()) {
                    retorno = rs.getObject(1);
                }
            }
        } finally {
            desconectar();
        }
        return retorno;
    }

    /**
     * Executa consultas SQL
     *
     * @param pst Comando PreparedStatement criado com o SQL e seus parâmetros
     * @return Object - Retorna se a consulta foi executrada com sucesso
     */
    public boolean executar(PreparedStatement pst)
            throws SQLException, Exception {
        boolean retorno = false;
        try {
            pst.execute();
            retorno = true;
        } finally {
            desconectar();
        }
        return retorno;
    }

    /**
     * Executa consultas SQL com retorno
     *
     * @param pst Comando PreparedStatement criado com o SQL e seus parâmetros
     * @return ResultSet - Retorno do registro consultado
     */
    public ResultSet executarSQL(PreparedStatement pst)
            throws SQLException, Exception {
        ResultSet retorno = null;
        try {
            rs = pst.executeQuery();
            retorno = rs;
        } finally {
            fechar(conexao);
            fechar(stm);
        }
        return rs;
    }

    /**
     * Executa insert/update/ SQL
     *
     * @param pst Comando PreparedStatement criado com o SQL e seus parâmetros
     * @return int - Id do registro inserido
     */
    public int executarUpdateSQL(PreparedStatement pst)
            throws SQLException, Exception {
        int retorno = 0;
        try {
            int ret = pst.executeUpdate();
            if (pst.toString().contains("RETURNING")) {
                // Captura o id do registro inserido
                rs = pst.getGeneratedKeys();
                while (rs.next()) {
                    retorno = rs.getInt(1);
                }
            } else {
                retorno = ret;
            }            
        } finally {
            desconectar();
        }
        return retorno;
    }  

    /**
     * Retorna o status da conexão True = Conectado / False = Desconectado
     *
     * @return boolean - Status atual da conexão
     */
    public boolean getStatusConexao() {
        try {
            status = (conexao != null && !conexao.isClosed());
        } catch (SQLException ex) {
            status = false;
        }
        return status;
    }
}
