package controler;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author Wechisley Faria
 */
public class Banco {

    private Conexao con;

    public Banco() {
        con = new Conexao();
        con.setConnection("localhost", "5432", "", "postgres", "postgres");
    }

    /**
     * Verifica se o banco de dados existe
     *
     * @return boolean - Informa se o banco de dados existe
     */
    public boolean bancoExiste() {
        boolean sucesso = false;
        try {
            // Verifica se o banco de dados existe
            String SQL = "SELECT EXISTS(SELECT datname FROM pg_catalog.pg_database WHERE datname='db_vr') as banco;";
            sucesso = (boolean) con.executarSQL(SQL);
            // Caso o banco exista, seta os dados para conexão
            if (sucesso) {
                con.setConnection("localhost", "5432", "db_vr", "postgres", "postgres");
            }
        } catch (Exception ex) {
            sucesso = false;
            System.err.println("Erro ao verificar Banco de dados!\nErro: " + ex.getMessage());
        }
        return sucesso;
    }

    /**
     * Se banco de dados não existir, cria e executa o srcipt SQL para gerar a
     * estrutura dos dados
     *
     * @return boolean - Informa se o banco de dados foi criado
     */
    public boolean criarBanco() {
        boolean sucesso = false;
        try {
            // Comando para criar o banco de dados
            String SQL = "CREATE DATABASE db_vr;";
            if (con.executar(SQL)) {
                // Confirma se o banco de dados existe, para gerar a estrutura
                if (bancoExiste()) {
                    if (criarTabelas()) {
                        JOptionPane.showMessageDialog(null, "Banco de dados db_vr, criado com sucesso!", "Banco de Dados", JOptionPane.INFORMATION_MESSAGE);
                        sucesso = true;
                    } else {
                        sucesso = false;
                        JOptionPane.showMessageDialog(null, "Falha ao criar estrutura do banco de dados db_vr!", "Banco de Dados", JOptionPane.WARNING_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Falha ao criar banco de dados db_vr!", "Banco de Dados", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            sucesso = false;
            System.err.println("Erro geral ao criar Banco de dados!\nErro: " + ex.getMessage());
        }
        return sucesso;
    }

    /**
     * Executa o script SQL para criação da estrutura do banco de dados (tabelas
     * e relacionamentos)
     *
     * @return boolean - Informa se todos os comandos foram executads com
     * sucesso
     */
    private boolean criarTabelas() {
        boolean sucesso = true;
        // Delimitador de linhas
        String delimiter = ";";

        File inputFile = new File("Bancoo.sql");
        if (!inputFile.exists()) {
            int respostaConfirmacao = JOptionPane.showConfirmDialog(null, "Arquivo banco.sql não encontrado!\nDeseja abrir o arquivo SQL agora?", "Banco de Dados", JOptionPane.YES_NO_OPTION);
            if (respostaConfirmacao == JOptionPane.YES_OPTION) {
                JFileChooser file = new JFileChooser();
                file.setFileSelectionMode(JFileChooser.FILES_ONLY);
                FileNameExtensionFilter filter = new FileNameExtensionFilter("SQL FILES", "sql");
                file.setFileFilter(filter);
                int i = file.showOpenDialog(null);
                if (i != 1) {
                    File arquivo = file.getSelectedFile();
                    inputFile = arquivo;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }

        // Criando scanner
        Scanner scanner;
        try {
            scanner = new Scanner(inputFile).useDelimiter(delimiter);
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
            return false;
        }

        // Percorre o Loop até que termine todos os comandos SQL
        while (scanner.hasNext() && sucesso == true) {
            String SQL = scanner.next() + delimiter;
            try {
                // Executa o comando
                sucesso = con.executar(SQL);
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro ao criar tabelas no banco de dados!\nERRO: " + ex.getMessage(), "Banco de Dados", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Erro geral ao criar tabelas no banco de dados!\nERRO: " + ex.getMessage(), "Banco de Dados", JOptionPane.ERROR_MESSAGE);
            }
        }
        return sucesso;
    }
}
