package model.bean;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JLabel;

/**
 *
 * @author Wechisley Faria
 */
public class Validacao {

    /**
     * Efetua a validação, para verificar se o campo está vazio
     *
     * @param codigo Código a ser verificado
     * @param nome Nome a ser verificado
     * @return Vazio = Validação ok / Não vazio = mensagem com os erros
     */
    public static String validaCamposAluno(String codigo, String nome) {
        String retorno = "";

        if (codigo.equalsIgnoreCase("") || "".equals(codigo)) {
            retorno += ">>>>> Código do Aluno\n";
        } else if (codigo.length() > 10) {
            retorno += ">>>>> Código do Aluno (tamanho máximo: 10)\n";
        }

        if (nome.equalsIgnoreCase("") || "".equals(nome)) {
            retorno += ">>>>> Nome do Aluno\n";
        } else if (nome.length() > 50) {
            retorno += ">>>>> Nome do Aluno (tamanho máximo: 50)";
        }
        return retorno;
    }

    /**
     * Efetua a validação, para verificar se o campo está vazio
     *
     * @param codigo Código a ser verificado
     * @param descricao Descrição a ser verificada
     * @param ementa Ementa a ser verificada
     * @return Vazio = Validação ok / Não vazio = mensagem com os erros
     */
    public static String validaCamposCurso(String codigo, String descricao, String ementa) {
        String retorno = "";

        if (codigo.equalsIgnoreCase("") || "".equals(codigo)) {
            retorno += ">>>>> Código do Curso\n";
        } else if (codigo.length() > 10) {
            retorno += ">>>>> Código do Curso (tamanho máximo: 10)\n";
        }

        if (descricao.equalsIgnoreCase("") || "".equals(descricao)) {
            retorno += ">>>>> Nome do Curso\n";
        } else if (descricao.length() > 50) {
            retorno += ">>>>> Nome do Curso (tamanho máximo: 50)\n";
        }

        if (ementa.equalsIgnoreCase("") || "".equals(ementa)) {
            retorno += ">>>>> Ementa do Curso\n";
        } else if (ementa.length() > 200) {
            retorno += ">>>>> Ementa do Curso (tamanho máximo: 200)";
        }
        return retorno;
    }

    public static void start(final JLabel textFieldHorario) {
        Thread atualizaHora;
        atualizaHora = new Thread(() -> {
            try {
                while (true) {
                    Date date = new Date();
                    StringBuilder data = new StringBuilder();
                    
                    //Para Atualizar a DATA so mudar para o formato dd/MM/yyyy
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                    textFieldHorario.setText(data.toString() + sdf.format(date));
                    Thread.sleep(30000);
                    textFieldHorario.revalidate();
                }
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        });
        atualizaHora.start();
    }
}
