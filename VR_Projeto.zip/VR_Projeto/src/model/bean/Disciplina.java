package model.bean;

/**
 *
 * @author Wechisley Faria
 */
public class Disciplina {

    private int codigo;
    private Aluno aluno;
    private Curso curso;
    private boolean deletar; //Informa se irá deletar o registro do banco
    private int totalAlunos; // Toal de alunos matriculados na disciplina

    public Disciplina() {
        aluno = new Aluno();
        curso = new Curso();
    }

    public int getCodigo() {
        return codigo;
    }

    public String getCodigo_Str() {
        return String.valueOf(codigo);
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public boolean isDeletar() {
        if (aluno.getCodigo() <= 0) {
            return false;
        } else {
            return deletar;
        }
    }

    public void setDeletar(boolean deletar) {
        if (aluno.getCodigo() <= 0) {
            this.deletar = false;
        } else {
            this.deletar = deletar;
        }
    }
    
    public int getTotalAlunos() {
        return totalAlunos;
    }

    public void setTotalAlunos(int totalAlunos) {
        this.totalAlunos = totalAlunos;
    }    
}
