package model.bean;

/**
 *
 * @author Wechisley Faria
 */
public class Aluno {
    private int codigo;
    private String nome;   
    
    public int getCodigo() {
        return codigo;
    }

    public String getCodigo_Str() {
        return String.valueOf(codigo);
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }    

    @Override
    public String toString() {
        return getNome()+ " ["+getCodigo_Str()+"]";
    }
}
