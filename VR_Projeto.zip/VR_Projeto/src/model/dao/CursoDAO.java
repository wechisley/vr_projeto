package model.dao;

import controler.Conexao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.bean.Curso;

/**
 *
 * @author Wechisley Faria
 */
public class CursoDAO {

    private Conexao con;
    private PreparedStatement pst;

    public CursoDAO() {
        con = new Conexao();
    }

    public String gravar(Curso curso)
            throws SQLException, Exception {
        String retorno = null;
        try {
            String SQL = "INSERT INTO tab_curso (cur_descricao, cur_ementa) VALUES (?, ?)";
            pst = con.getConexao().prepareStatement(SQL, PreparedStatement.RETURN_GENERATED_KEYS);
            pst.clearParameters();
            pst.setString(1, curso.getDescricao());
            pst.setString(2, curso.getEmenta());            

            curso.setCodigo(con.executarUpdateSQL(pst));
            retorno = (curso.getCodigo() > 0) ? null : "Erro ao gravar curso!";
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = "Erro ao Inserir!\nErro: " + ex.getMessage();
        } catch (Exception ex) {
            ex.printStackTrace();
            retorno = "Erro geral ao Inserir!\nErro: " + ex.getMessage();
        } finally {
            con.fechar(pst);
        }
        return retorno;
    }

    public String atualizar(Curso curso)
            throws SQLException, Exception {
        String retorno = null;
        try {
            String SQL = "UPDATE tab_curso SET cur_descricao = ?, cur_ementa = ? WHERE cur_codigo = ?;";
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setString(1, curso.getDescricao());
            pst.setString(2, curso.getEmenta());
            pst.setInt(3, curso.getCodigo());

            retorno = (con.executarUpdateSQL(pst) > 0) ? null : "Erro ao atualizar curso!";
        } finally {
            con.fechar(pst);
        }
        return retorno;
    }

    public String excluir(Integer codigo)
            throws SQLException, Exception {
        String retorno = null;
        try {
            String SQL = "DELETE FROM tab_curso where cur_codigo = ?";
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setInt(1, codigo);

            retorno = (con.executarUpdateSQL(pst) > 0) ? null : "Erro ao Excluir curso!";
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = "Erro ao Excluir!\nErro: " + ex.getMessage();
        } catch (Exception ex) {
            ex.printStackTrace();
            retorno = "Erro geral ao Excluir!\nErro: " + ex.getMessage();
        } finally {
            con.fechar(pst);
        }
        return retorno;
    }

    public List<Curso> buscaDescricaoEmenta(String procura, char tipo)
            throws SQLException, Exception {
        ResultSet rs = null;
        String tipoBusca = (tipo == 'E') ? "cur_ementa" : "cur_descricao";
        String SQL = "SELECT * FROM tab_curso where "+tipoBusca+" like (?) order by "+tipoBusca+";";
        List<Curso> listaCursos = null;
        try {
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setString(1, "%" + procura + "%");

            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaCursos == null) {
                    listaCursos = new ArrayList<Curso>();
                }
                Curso curso = new Curso();
                curso.setCodigo(rs.getInt("cur_codigo"));
                curso.setDescricao(rs.getString("cur_descricao"));
                curso.setEmenta(rs.getString("cur_ementa"));

                listaCursos.add(curso);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaCursos;
    }           

    public List<Curso> buscaCodigo(String codigo)
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM tab_curso where cast(cur_codigo as text) like (?) order by cur_codigo;";
        List<Curso> listaCursos = null;
        try {
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setString(1, "%" + codigo + "%");

            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaCursos == null) {
                    listaCursos = new ArrayList<Curso>();
                }
                Curso curso = new Curso();
                curso.setCodigo(rs.getInt("cur_codigo"));
                curso.setDescricao(rs.getString("cur_descricao"));
                curso.setEmenta(rs.getString("cur_ementa"));

                listaCursos.add(curso);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaCursos;
    }

    public Curso procurarCodigo(Integer codigo)
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM tab_curso where cur_codigo = ?;";
        try {
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setInt(1, codigo);

            rs = (ResultSet) con.executarSQL(pst);
            if (rs.next()) {
                Curso curso = new Curso();
                curso.setCodigo(rs.getInt("cur_codigo"));
                curso.setDescricao(rs.getString("cur_descricao"));
                curso.setEmenta(rs.getString("cur_ementa"));

                return curso;
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return null;
    }
    
    public List<Curso> buscaCursosDisponiveis()
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM tab_curso c WHERE NOT EXISTS (SELECT ca.cal_codigo_curso FROM tab_curso_aluno ca WHERE ca.cal_codigo_curso = c.cur_codigo) order by cur_descricao;";
        List<Curso> listaCursos = null;
        try {
            pst = con.getConexao().prepareStatement(SQL);
            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaCursos == null) {
                    listaCursos = new ArrayList<Curso>();
                }
                Curso curso = new Curso();
                curso.setCodigo(rs.getInt("cur_codigo"));
                curso.setDescricao(rs.getString("cur_descricao"));
                curso.setEmenta(rs.getString("cur_ementa"));

                listaCursos.add(curso);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaCursos;
    }
    
    public List<Curso> buscaTodos()
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM tab_curso order by cur_descricao;";
        List<Curso> listaCursos = null;
        try {
            pst = con.getConexao().prepareStatement(SQL);
            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaCursos == null) {
                    listaCursos = new ArrayList<Curso>();
                }
                Curso curso = new Curso();
                curso.setCodigo(rs.getInt("cur_codigo"));
                curso.setDescricao(rs.getString("cur_descricao"));
                curso.setEmenta(rs.getString("cur_ementa"));

                listaCursos.add(curso);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaCursos;
    }
}