package model.dao;

import controler.Conexao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.bean.Aluno;

/**
 *
 * @author Wechisley Faria
 */
public class AlunoDAO {

    private Conexao con;
    private PreparedStatement pst;

    public AlunoDAO() {
        con = new Conexao();
    }

    public String gravar(Aluno aluno)
            throws SQLException, Exception {
        String retorno = null;
        try {
            String SQL = "INSERT INTO tab_aluno (alu_nome) VALUES (?)";
            pst = con.getConexao().prepareStatement(SQL, PreparedStatement.RETURN_GENERATED_KEYS);
            pst.clearParameters();
            pst.setString(1, aluno.getNome());

            aluno.setCodigo(con.executarUpdateSQL(pst));
            retorno = (aluno.getCodigo() > 0) ? null : "Erro ao gravar aluno!";
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = "Erro ao Inserir!\nErro: " + ex.getMessage();
        } catch (Exception ex) {
            ex.printStackTrace();
            retorno = "Erro geral ao Inserir!\nErro: " + ex.getMessage();
        } finally {
            con.fechar(pst);
        }
        return retorno;
    }

    public String atualizar(Aluno aluno)
            throws SQLException, Exception {
        String retorno = null;
        try {
            String SQL = "UPDATE tab_aluno SET alu_nome = ? WHERE alu_codigo = ?;";
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setString(1, aluno.getNome());
            pst.setInt(2, aluno.getCodigo());

            retorno = (con.executarUpdateSQL(pst) > 0) ? null : "Erro ao atualizar aluno!";
        } finally {
            con.fechar(pst);
        }
        return retorno;
    }

    public String excluir(Integer codigo)
            throws SQLException, Exception {
        String retorno = null;
        try {
            String SQL = "DELETE FROM tab_aluno where alu_codigo = ?";
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setInt(1, codigo);

            retorno = (con.executarUpdateSQL(pst) > 0) ? null : "Erro ao Excluir aluno!";
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = "Erro ao Excluir!\nErro: " + ex.getMessage();
        } catch (Exception ex) {
            ex.printStackTrace();
            retorno = "Erro geral ao Excluir!\nErro: " + ex.getMessage();
        } finally {
            con.fechar(pst);
        }
        return retorno;
    }

    public List<Aluno> buscaNome(String nome)
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM tab_aluno where alu_nome like (?) order by alu_nome;";
        List<Aluno> listaAlunos = null;
        try {
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setString(1, "%" + nome + "%");

            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaAlunos == null) {
                    listaAlunos = new ArrayList<Aluno>();
                }
                Aluno aluno = new Aluno();
                aluno.setCodigo(rs.getInt("alu_codigo"));
                aluno.setNome(rs.getString("alu_nome"));

                listaAlunos.add(aluno);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaAlunos;
    }

    public List<Aluno> buscaCodigo(String codigo)
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM tab_aluno where cast(alu_codigo as text) like (?) order by alu_codigo;";
        List<Aluno> listaAlunos = null;
        try {
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setString(1, "%" + codigo + "%");

            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaAlunos == null) {
                    listaAlunos = new ArrayList<Aluno>();
                }
                Aluno aluno = new Aluno();
                aluno.setCodigo(rs.getInt("alu_codigo"));
                aluno.setNome(rs.getString("alu_nome"));

                listaAlunos.add(aluno);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaAlunos;
    }

    public Aluno procurarCodigo(Integer codigo)
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM tab_aluno where alu_codigo = ?;";
        try {
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setInt(1, codigo);

            rs = (ResultSet) con.executarSQL(pst);
            if (rs.next()) {
                Aluno aluno = new Aluno();
                aluno.setCodigo(rs.getInt("alu_codigo"));
                aluno.setNome(rs.getString("alu_nome"));

                return aluno;
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return null;
    }
    
    public List<Aluno> buscaTodos()
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM tab_aluno order by alu_nome;";
        List<Aluno> listaAlunos = null;
        try {
            pst = con.getConexao().prepareStatement(SQL);
            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaAlunos == null) {
                    listaAlunos = new ArrayList<Aluno>();
                }
                Aluno aluno = new Aluno();
                aluno.setCodigo(rs.getInt("alu_codigo"));
                aluno.setNome(rs.getString("alu_nome"));

                listaAlunos.add(aluno);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaAlunos;
    }    
}