package model.dao;

import controler.Conexao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.bean.Disciplina;

/**
 *
 * @author Wechisley Faria
 */
public class DisciplinaDAO {

    private Conexao con;
    private PreparedStatement pst;

    public DisciplinaDAO() {
        con = new Conexao();
    }

    /**
     * Grava, atualiza e deleta os dados das disciplinas em uma transação
     * @param listaDisciplinas List com todos os dados da disciplina (disciplina, curso e aluno)
     * @return String com o erro ocorrido ou NULL quando o processo for concluído
     */
    public String gravar(List<Disciplina> listaDisciplinas) throws Exception {
        String retorno = null;

        PreparedStatement pstIns = null;
        PreparedStatement pstUpd = null;
        PreparedStatement pstDel = null;
        ResultSet rs = null;

        String SQLInsert = "INSERT INTO tab_curso_aluno (cal_codigo_aluno, cal_codigo_curso) VALUES (?, ?);";
        String SQLUpdate = "UPDATE tab_curso_aluno SET cal_codigo_aluno = ?, cal_codigo_curso = ? WHERE cal_codigo = ?;";
        String SQLDelete = "DELETE FROM tab_curso_aluno where cal_codigo = ?;";

        try {
            con.getConexao().setAutoCommit(false);

            for (Disciplina disciplina : listaDisciplinas) {
                if (disciplina.isDeletar()) { // Deletar
                    pstDel = con.getConexao().prepareStatement(SQLDelete);
                    pstDel.setInt(1, disciplina.getCodigo());

                    retorno = (pstDel.executeUpdate() > 0) ? null : "Erro ao Excluir disciplina!";
                } else if (disciplina.getCodigo() > 0) { //Atualizar
                    pstUpd = con.getConexao().prepareStatement(SQLUpdate);
                    pstUpd.setInt(1, disciplina.getAluno().getCodigo());
                    pstUpd.setInt(2, disciplina.getCurso().getCodigo());
                    pstUpd.setInt(3, disciplina.getCodigo());

                    retorno = (pstUpd.executeUpdate() > 0) ? null : "Erro ao atualizar aluno!";
                } else { //Inserir
                    pstIns = con.getConexao().prepareStatement(SQLInsert, PreparedStatement.RETURN_GENERATED_KEYS);
                    pstIns.setInt(1, disciplina.getAluno().getCodigo());
                    pstIns.setInt(2, disciplina.getCurso().getCodigo());

                    if (pstIns.executeUpdate() > 0) {
                        rs = pstIns.getGeneratedKeys();
                        if (rs.next()) {
                            disciplina.setCodigo(rs.getInt(1));
                        }
                    }
                    retorno = (disciplina.getCodigo() > 0) ? null : "Erro ao gravar disciplina!";
                }
                //Verifica se ocorreu algum erro
                if (retorno != null) {
                    break;
                }
            }
            //Verifica se ocorreu algum erro
            if (retorno != null) {
                con.getConexao().rollback();
            } else {
                con.getConexao().commit();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = (retorno != null) ? retorno + "\n" : "" + "Erro na transação de Disciplina!\nErro: " + ex.getMessage();
            try {
                if (con.getConexao() != null) {
                    con.getConexao().rollback();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                retorno = retorno + "\nErro ao desfazer transação (rollback).";
            }
        } finally {
            con.getConexao().setAutoCommit(true);
            con.fechar(rs)
                    .fechar(pstIns)
                    .fechar(pstUpd)
                    .fechar(pstDel)
                    .fechar(con.getConexao());
        }
        return retorno;
    }

    /**
     * Exclui a disciplina (com todos os alunos matriculados)
     * @param codCurso Código do curso a excluir
     * @return String com o erro ocorrido ou NULL quando o processo for concluído
     */    
    public String excluir(Integer codCurso)
            throws SQLException, Exception {
        String retorno = null;
        try {
            String SQL = "DELETE FROM tab_curso_aluno where cal_codigo_curso = ?";
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setInt(1, codCurso);

            retorno = (con.executarUpdateSQL(pst) > 0) ? null : "Erro ao Excluir disciplina!";
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = "Erro ao Excluir!\nErro: " + ex.getMessage();
        } catch (Exception ex) {
            ex.printStackTrace();
            retorno = "Erro geral ao Excluir!\nErro: " + ex.getMessage();
        } finally {
            con.fechar(pst);
        }
        return retorno;
    }
    
    /**
     * Busca todas as disciplinas onde o aluno está matriculado
     *
     * @param procura Nome do aluno
     * @return (List de Aluno) Lista com todos os alunos
     */
    public List<Disciplina> buscaAlunoDisciplina(String procura)
            throws SQLException, Exception {
        ResultSet rs = null;
        StringBuilder SQL = new StringBuilder();

        SQL.append("SELECT * FROM (SELECT DISTINCT ON (a.cal_codigo_curso) a.cal_codigo, a.cal_codigo_aluno, a.alu_nome, a.cal_codigo_curso, a.cur_descricao, a.cur_ementa, a.alunos ");
        SQL.append("FROM (SELECT a1.cal_codigo, a1.cal_codigo_aluno, a1.alu_nome, a1.cal_codigo_curso, a1.cur_descricao, a1.cur_ementa, ");
        SQL.append("(SELECT count(a2.cal_codigo_aluno) AS alunos FROM vie_disciplina a2 WHERE a2.cal_codigo_curso = a1.cal_codigo_curso) AS alunos FROM vie_disciplina a1) a ");
        SQL.append("WHERE a.alu_nome like (?)) b ");
        SQL.append("ORDER BY cur_descricao");
        List<Disciplina> listaDisciplinas = null;
        try {
            pst = con.getConexao().prepareStatement(SQL.toString());
            pst.clearParameters();
            pst.setString(1, "%" + procura + "%");

            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaDisciplinas == null) {
                    listaDisciplinas = new ArrayList<Disciplina>();
                }
                Disciplina disciplina = new Disciplina();
                disciplina.setCodigo(rs.getInt("cal_codigo"));
                // Adiciona Aluno                
                disciplina.getAluno().setCodigo(rs.getInt("cal_codigo_aluno"));
                disciplina.getAluno().setNome(rs.getString("alu_nome"));
                // Adiciona Curso
                disciplina.getCurso().setCodigo(rs.getInt("cal_codigo_curso"));
                disciplina.getCurso().setDescricao(rs.getString("cur_descricao"));
                disciplina.getCurso().setEmenta(rs.getString("cur_ementa"));
                disciplina.setDeletar(false);
                disciplina.setTotalAlunos(rs.getInt("alunos"));

                listaDisciplinas.add(disciplina);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaDisciplinas;
    }

    /**
     * Busca todas as disciplinas, através do código do curso
     *
     * @param codigo Código do curso
     * @return (List de Aluno) Lista com todos os alunos
     */
    public List<Disciplina> buscaCodigoCurso(String codigo)
            throws SQLException, Exception {
        ResultSet rs = null;
        StringBuilder SQL = new StringBuilder();
        SQL.append("SELECT * FROM vie_disciplina_alunos ");
        SQL.append("WHERE cast(cal_codigo_curso as text) ");
        SQL.append("like (?) ");
        SQL.append("ORDER BY cal_codigo_curso;");
        List<Disciplina> listaDisciplinas = null;
        try {
            pst = con.getConexao().prepareStatement(SQL.toString());
            pst.clearParameters();
            pst.setString(1, "%" + codigo + "%");

            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaDisciplinas == null) {
                    listaDisciplinas = new ArrayList<Disciplina>();
                }
                Disciplina disciplina = new Disciplina();
                disciplina.setCodigo(rs.getInt("cal_codigo"));
                // Adiciona Aluno                
                disciplina.getAluno().setCodigo(rs.getInt("cal_codigo_aluno"));
                disciplina.getAluno().setNome(rs.getString("alu_nome"));
                // Adiciona Curso
                disciplina.getCurso().setCodigo(rs.getInt("cal_codigo_curso"));
                disciplina.getCurso().setDescricao(rs.getString("cur_descricao"));
                disciplina.getCurso().setEmenta(rs.getString("cur_ementa"));
                disciplina.setDeletar(false);
                disciplina.setTotalAlunos(rs.getInt("alunos"));

                listaDisciplinas.add(disciplina);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaDisciplinas;
    }

    /**
     * Busca todas as disciplinas, através da Descrição do Curso
     *
     * @param procura Nome do Curso
     * @return (List de Aluno) Lista com todos os alunos
     */    
    public List<Disciplina> buscaDescricaoCurso(String procura)
            throws SQLException, Exception {
        ResultSet rs = null;
        StringBuilder SQL = new StringBuilder();

        SQL.append("SELECT * FROM vie_disciplina_alunos ");
        SQL.append("WHERE cur_descricao like (?) ");
        SQL.append("ORDER BY cur_descricao;");
        List<Disciplina> listaDisciplinas = null;
        try {
            pst = con.getConexao().prepareStatement(SQL.toString());
            pst.clearParameters();
            pst.setString(1, "%" + procura + "%");

            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaDisciplinas == null) {
                    listaDisciplinas = new ArrayList<Disciplina>();
                }
                Disciplina disciplina = new Disciplina();
                disciplina.setCodigo(rs.getInt("cal_codigo"));
                // Adiciona Aluno                
                disciplina.getAluno().setCodigo(rs.getInt("cal_codigo_aluno"));
                disciplina.getAluno().setNome(rs.getString("alu_nome"));
                // Adiciona Curso
                disciplina.getCurso().setCodigo(rs.getInt("cal_codigo_curso"));
                disciplina.getCurso().setDescricao(rs.getString("cur_descricao"));
                disciplina.getCurso().setEmenta(rs.getString("cur_ementa"));
                disciplina.setDeletar(false);
                disciplina.setTotalAlunos(rs.getInt("alunos"));

                listaDisciplinas.add(disciplina);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaDisciplinas;
    }    
    
    /**
     * Busca todas as disciplinas, através do código do curso
     * @param codigo Código do curso
     * @return (List de Aluno) Lista com todos os alunos
     */
    public List<Disciplina> procurarCodigoCurso(Integer codigo)
            throws SQLException, Exception {
        ResultSet rs = null;
        String SQL = "SELECT * FROM vie_disciplina where cal_codigo_curso = ?;";
        List<Disciplina> listaDisciplinas = null;
        try {
            pst = con.getConexao().prepareStatement(SQL);
            pst.clearParameters();
            pst.setInt(1, codigo);

            rs = (ResultSet) con.executarSQL(pst);
            while (rs.next()) {
                if (listaDisciplinas == null) {
                    listaDisciplinas = new ArrayList<Disciplina>();
                }
                Disciplina disciplina = new Disciplina();
                disciplina.setCodigo(rs.getInt("cal_codigo"));
                // Adiciona Aluno                
                disciplina.getAluno().setCodigo(rs.getInt("cal_codigo_aluno"));
                disciplina.getAluno().setNome(rs.getString("alu_nome"));
                // Adiciona Curso
                disciplina.getCurso().setCodigo(rs.getInt("cal_codigo_curso"));
                disciplina.getCurso().setDescricao(rs.getString("cur_descricao"));
                disciplina.getCurso().setEmenta(rs.getString("cur_ementa"));

                listaDisciplinas.add(disciplina);
            }
        } finally {
            con.fechar(rs);
            con.fechar(pst);
        }
        return listaDisciplinas;
    }
}